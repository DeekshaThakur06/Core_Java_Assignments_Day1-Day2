package ProblemStatement6_2;
import java.util.*;
import java.util.HashSet;
public class Product {

	public static void main(String[] args) {
		HashSet <String> products = new HashSet<>();
		/*ArrayList <String> product_name = new ArrayList<>();
		ArrayList <Integer> product_id = new ArrayList<>();
		
		*/
		Scanner input1 = new Scanner(System.in);
		Scanner input2 = new Scanner(System.in);
		//Scanner input3 = new Scanner(System.in);
		Scanner input4 = new Scanner(System.in);
		Scanner input5 = new Scanner(System.in);
		System.out.println("Enter number of products you want to enter");
		int n = input1.nextInt();
		String Product_id = null;
		String Product_Name = null;
		for(int i = 0 ; i < n ; i++) {
			System.out.println("Enter Product_ID");
			Product_id = input2.nextLine();
			products.add(Product_id);
			System.out.println("Enter Product_Name");
			Product_Name = input2.nextLine();
			products.add(Product_Name);
			

		}
		System.out.println("Products : " +products);
		System.out.println("Enter the product you want to search : ");
		String search = input4.nextLine();
		if(products.contains(search)) {
			System.out.println("Product found");
		}
		else {
			System.out.println("Product not found");
		}
		System.out.println("Enter the product you want to remove using product_id");
		String remove = input5.nextLine();
		products.remove(remove);
		System.out.println("After removal of product " + products);
		//System.out.println("Product_Id :" + Product_id + "Product_Name" + Product_Name);

	}

}
