package ProblemStatement1_4;
import java.util.*;
public class Rectangle {
	private float length = 1;
    private float breadth = 1  ;
    
    public float Perimeter(float l, float b) {
    	
    	float perimeter = 2 * (l + b);
    	return perimeter;
    	
    }
    
    public float getLength() {
		return length;
	}

	public void setLength(float length) {
		if(length>=0.0 && length<=20.0)
		this.length = length;

	}

	public float getBreadth() {
		return breadth;
	}

	public void setBreadth(float breadth) {
		if(breadth>=0.0 && breadth<=20.0)
		this.breadth = breadth;
		
		}
	

	public float area(float l , float b) {
		float area = l * b;
    	return area;
    	
    }
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		Rectangle rect = new Rectangle();
		System.out.println("Enter length :");
		float l = scanner.nextFloat();
		rect.setLength(l);
		System.out.println("Enter breadth :");
		float b = scanner.nextFloat();
		rect.setBreadth(b);
		
		float length = rect.getLength();
		float breadth = rect.getBreadth();
		
		System.out.println("Perimeter : " + rect.Perimeter(length,breadth));
		System.out.println("Area : " + rect.area(length,breadth));
		
     
     
	}

}
