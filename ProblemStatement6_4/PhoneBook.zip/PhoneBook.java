package ProblemStatement6_4;

import java.util.HashMap;
import java.util.Scanner;

public class PhoneBook {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   HashMap<String,Long> p_book = new HashMap<>();
   Scanner e1 = new Scanner(System.in);
   Scanner e2 = new Scanner(System.in);
   Scanner e3 = new Scanner(System.in);
   Scanner e4 = new Scanner(System.in);
   Scanner e5 = new Scanner(System.in);
   String name = null;
   Long number = null;
   // Adding new phone book entry
   
   
   System.out.println("-----------------------------------");
   
	   
   System.out.println("Number of entries you wanted to do ?");
   int entry = e1.nextInt();
   for(int i = 0 ; i < entry ;i++) {
	   
	  System.out.println("Enter Name : ");
	   name = e2.nextLine();
	  System.out.println("Enter Number : ");
	   number = e3.nextLong();
	  p_book.put(name,number);
	  
	  
   }
   System.out.println(p_book);
   System.out.println("-----------------------------------");
   
  
// Searching phone number

	  System.out.println("Enter User Name");
	  String search = e4.next();
	  if(p_book.containsKey(search)) {
		  System.out.println("Phone number exists : " + p_book.get(search));
	  }
	  else {
		  System.out.println("Phone number does n't exists..");
	  }
	  System.out.println("-----------------------------------");
  
	   
	}


	}
