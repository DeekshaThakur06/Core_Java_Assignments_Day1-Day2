package ProblemStatement5_2;

public class Expression {

	public static void main(String[] args) {
		String str = "23 + 45 - ( 343 / 12 ) ";
		String exp[] = str.split(" ");
		for(int i = 0 ; i < exp.length ; i++ ) {
			System.out.println(exp[i]);
		}
	}

}
