package ProblemStatement1_1;
import java.util.Scanner;
public class EvenNumbers {

	public static void main(String[] args) {
    Scanner snr = new Scanner(System.in);
    System.out.println("Enter a number :");
    int num = snr.nextInt();
    System.out.println("Even numbers less than or equal to number.");
    for(int i = 0; i <= num ;i++) {
    	
    	if(i % 2 == 0) {
    		System.out.println(i);	
    	}
    	
    }
	}

}
