package ProblemStatement4;

import java.util.Scanner;

public class BankAccount {
   
	int accNo;
	String custName;
	String accType1;
	String accType2;
	float balance;
	float initialBalance;
	float currentBalance;
	float savings;
	public void deposit(float amt) {
		try {
			
			if(amt > 0 ) {
				this.currentBalance = currentBalance + amt;
			}
			else {
				throw new Exception("Negative amount Exception");
			}
		}
		catch(Exception e) {
			e.printStackTrace();
			
		}
		
	}
	public void withdraw(float amt) {
		try {
			if(savings>=1000 && currentBalance >=5000) {
				this.currentBalance = currentBalance - amt;
			}
			else {
				throw new Exception("Insuficient Funds.");
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	BankAccount(int account_Number, String customer_Name, String Account_Type1,String Account_Type2, float Current,float Savings){
		
		this.accNo = account_Number;
		this.custName = customer_Name;
		this.accType1 = Account_Type1;
		this.accType2 = Account_Type2;
		this.currentBalance = Current;
		this.savings = Savings;
	}
	public float getBalance() {
		
		try {
		if(savings >= 1000 && currentBalance >=5000) {
			System.out.println("Current Balance : Rs." + currentBalance);
			System.out.println("Savings Balance : Rs." + savings);
			}
		else {
			throw new Exception("Low Balance Exception");
		}
	}
		catch(Exception e) {
			System.out.println("Current Balance : Rs." + currentBalance);
			System.out.println("Savings Balance : Rs." + savings);
			e.printStackTrace();
		}
		
		return currentBalance ;}
	    public static void main(String[] args) {
		Scanner input1 = new Scanner(System.in);
		Scanner input2 = new Scanner(System.in);
		Scanner input3 = new Scanner(System.in);
		Scanner input4 = new Scanner(System.in);
		Scanner input5 = new Scanner(System.in);
		Scanner input6 = new Scanner(System.in);
		Scanner input7 = new Scanner(System.in);
		Scanner input8 = new Scanner(System.in);
		
		
		System.out.println("Enter Details...");
		System.out.println("------------------------------------------");
		System.out.println("Enter Account Number ");
		int accNum = input1.nextInt();
		System.out.println("Enter Customer Name :");
		String user = input2.nextLine();
		System.out.println("Enter Account Type : Savings/Current");
		String type1 = input3.nextLine();
		System.out.println("Enter Other Account Type : Savings/Current");
		String type2 = input8.nextLine();
		System.out.println("Initial Balance In Savings : ");
		float savings = input4.nextFloat();
		System.out.println("Initial Balance In Current");
		float current = input5.nextFloat();
		
		BankAccount acc = new BankAccount(accNum,user,type1,type2,current,savings);
		
		System.out.println("Enter amount to deposit");
		float deposit = input6.nextFloat();
		acc.deposit(deposit);
		System.out.println("------------------------------------------");
		System.out.println("Current Balance : Rs." + acc.currentBalance);
		System.out.println("------------------------------------------");
		System.out.println("Enter amount to withdraw:");
		float widthdraw = input7.nextFloat();
		acc.withdraw(widthdraw);
		System.out.println("------------------------------------------");
		System.out.println("Current Balance after withdrawl: Rs " + acc.currentBalance);
		System.out.println("------------------------------------------");
		
		acc.getBalance();
		
	}

}
