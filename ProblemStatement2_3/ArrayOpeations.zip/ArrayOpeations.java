package ProblemStatement2_3;

public class ArrayOpeations {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        int arr[] = {3,2,4,5,6,4,5,7,3,2,3,4,7,1,2,0,0,0};
        int sum = 0;
        int avg = 0;
        int i = 0 ;
        int small = arr[0];
        for( i = 0  ; i < arr.length-3 ; i++) {
        
        	
        		sum = sum + arr[i]; 
        		
        		avg = sum/2;
        		if(small>arr[i]) {
        			small = arr[i];
        		}
        		
        		}
        arr[15] = sum;
        arr[16] = avg;
        arr[17]=small;
        for(int array : arr) {
        	System.out.print(" " + array);
        }
        	
        
        
	}

}
