package ProblemStatement2_1;

import java.util.Scanner;

public class Strings {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter String : ");
		String str = scanner.next();
		System.out.println("Length of string : " + str.length());
		System.out.println("To UpperCase :" + str.toUpperCase());
		String revStr = "";
		for(int i = str.length()-1 ; i>=0; --i) {
			revStr = revStr + str.charAt(i);
		}
			if(str.toUpperCase().equals(revStr.toUpperCase())) {
				System.out.print("It is Palindrome");
			}
			else {
				System.out.println("It is not a Palindrome");
			}
		}
		
		
		
		

	}


