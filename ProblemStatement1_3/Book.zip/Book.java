package ProblemStatement1_3;
import java.util.*;
public class Book {
 
	private String book_title;
	private double book_price;
	public String getBook_title() {
		return book_title;
	}
	public String setBook_title(String book_title) {
		return this.book_title = book_title;
	}
	public double getBook_price() {
		return book_price;
	}
	public double setBook_price(double price2) {
		return this.book_price = price2;
	}
	/*public String createBooks() {
		return "books";
	}*/
	public static void main(String[] args) throws InterruptedException {
	
		Book book = new Book();
		Scanner sc = new Scanner(System.in);
		Scanner sc1 = new Scanner(System.in);
		//System.out.println("How many book details you want to enter : ");
		
		System.out.println("Enter book title : ");
		String title1 = sc.nextLine();
		String book_title1 = book.setBook_title(title1);
		//Thread.sleep(5000);
		System.out.println("Enter price :");
		float price1 = sc.nextFloat();
		
		double book_price1 = book.setBook_price(price1);
		
	    
	    
	    System.out.println("Enter book title : ");
		String title2 = sc1.nextLine();
		String book_title2 = book.setBook_title(title2);
		//Thread.sleep(5000);
		System.out.println("Enter price :");
		double price2 = sc1.nextFloat();
		
		double book_price2 = book.setBook_price(price2);
		System.out.println("BOOK DETAILS :");
		System.out.println(book_title1 + " | " + " Rs " + book_price1 + " | ");
	    System.out.println(book_title2 + " | " + " Rs " + book_price2 + " | ");
		}
	
	}
	


