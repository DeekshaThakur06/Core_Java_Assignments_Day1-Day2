package ProblemStatement2_2;

import java.util.Scanner;

public class Fibonacci {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		/*System.out.println("Enter First Number :");
		int num1 = scanner.nextInt();
		System.out.println("Enter Second Number :");
		int num2 = scanner.nextInt();*/
	

			    int i = 1, n = 13, firstTerm = 0, secondTerm = 1;
			    System.out.println("Fibonacci Series till " + n + " terms:");

			    while (i <= n) {
			      System.out.print(firstTerm + ", ");

			      int nextTerm = firstTerm + secondTerm;
			      firstTerm = secondTerm;
			      secondTerm = nextTerm;

			      i++;
			    }
			  }
			}

		  
		
	


