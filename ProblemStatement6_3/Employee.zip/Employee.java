package ProblemStatement6_3;

import java.util.LinkedList;
import java.util.Scanner;

 class EmployeeDetails {

	private int eid;
	private String ename,address;
	public EmployeeDetails(int eid, String ename, String address) {
		super();
		this.eid = eid;
		this.ename = ename;
		this.address = address;
	}
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
}
public class Employee {
	
	private static LinkedList<EmployeeDetails> addInput() {
		EmployeeDetails e1 = new EmployeeDetails(1001, "Deeksha","Haryana");
		EmployeeDetails e2 = new EmployeeDetails(1002, "Tamanna","Delhi");
		EmployeeDetails e3 = new EmployeeDetails(1003, "Shubham","Noida");
		LinkedList<EmployeeDetails> e = new LinkedList<>();
		e.add(e1);
		e.add(e2);
		e.add(e3);
		return e;
	}

	public static void display(LinkedList<EmployeeDetails>v)
	{
		for(EmployeeDetails e:v)
		{
			System.out.println(e.getEid()+"\t"+e.getEname()+"\t"+e.getAddress());
		}
	}

	public static void main(String[]args) {

		LinkedList<EmployeeDetails> e = addInput();
		display(e);
		
	}
	}
	