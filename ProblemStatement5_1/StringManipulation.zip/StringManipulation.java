package ProblemStatement5_1;

public class StringManipulation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "JAVA is Simple";
		// a) TO UPPERCASE
		
		System.out.println(str.toUpperCase());
		System.out.println("------------------------------------------");
		// b) TO LOWERCASE
		System.out.println(str.toLowerCase());
		System.out.println("------------------------------------------");
		
		
		
			
		// c) First character of each word
		String[] first = str.split(" ");
		for(int i = 0 ; i < first.length;i++) {
			String frst = first[i];
			System.out.print(frst.charAt(0) + " ");
		}
		System.out.println("\n------------------------------------------");
		// d) Replacing first and third word
		String order[] = str.split(" ");
		for (int i = order.length-1  ; i>=0 ; i--) {
			String new_order = order[i];
			System.out.print(new_order + " ");
		}
		System.out.println("\n------------------------------------------");
		
		
		// e) Reverse Order
		String revOrder[] = str.split(" ");
		for (int i = 0  ; i<=revOrder.length-1 ; i++) {
			String new_order = revOrder[i];
			for(int j = new_order.length()-1; j>=0 ;--j)
			{
				char rev = new_order.charAt(j);
			
			System.out.print(rev + " ");
		}
			}
		// or
		System.out.println("\n-------------OR----------------");
		String reverse[] = str.split(" ");
		for(int k = 0 ; k <= reverse.length-1 ; k++) {
			String val = reverse[k];
			StringBuilder build = new StringBuilder(val);
			build.reverse();
			System.out.print(build + " ");
		}
		System.out.println("\n------------------------------------------");
		// f) Total Length
	 	int count = 0 ;
		for(int i = 0 ; i < str.length(); i++) {
			if(str.charAt(i) !=' ') {
				count = count + 1;
				
			}
		}
		
		System.out.println("\nTotal Length is : " +count);
	}

}
