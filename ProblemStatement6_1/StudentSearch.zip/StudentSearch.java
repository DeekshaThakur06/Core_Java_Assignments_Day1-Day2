package ProblemStatement6_1;
import java.util.ArrayList;
import java.util.Scanner;
public class StudentSearch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    ArrayList <String> student = new ArrayList<>();
    Scanner scanner = new Scanner(System.in);
    Scanner scanner1 = new Scanner(System.in);
    Scanner scanner2 = new Scanner(System.in);
    System.out.println("How many students you want to enter ?");
    int number = scanner1.nextInt();
    System.out.println("Enter Student's name :");
    
    for(int i = 0 ; i < number ; i ++) {
    String input = scanner.nextLine();
    student.add(input);
    }
    System.out.println(student);
    
    System.out.println("Student name you want to search...");
    
    String search = scanner2.nextLine();
    
    if(student.contains(search))
    {
    	System.out.println("Student exists");
    }
    else {
    	System.out.println("Student with such name doesn't exists..");
    }
	}
     
}
