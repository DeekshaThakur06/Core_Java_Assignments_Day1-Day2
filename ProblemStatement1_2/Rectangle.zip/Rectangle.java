package ProblemStatement1_2;

	
	import java.util.*;
	
	    public class Rectangle {
		private int length = 0;
		private int breadth = 0;
		public int getLength() {
			return length;
		}
		public void setLength(int length) {
			this.length = length;
		}
		public int getBreadth() {
			return breadth;
		}
		public void setBreadth(int breadth) {
			this.breadth = breadth;
		}
		public static void main(String[] args) {
			
			Rectangle rect = new Rectangle();
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter Length");
			int l = sc.nextInt();
			rect.setLength(l);
			System.out.println("Enter Breadth");
			int b = sc.nextInt();
			rect.setBreadth(b);
			int area = rect.getLength() * rect.getBreadth();
			System.out.println("Area of rectangle : " + area);
			

		}

	}

