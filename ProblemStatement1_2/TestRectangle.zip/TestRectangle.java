package ProblemStatement1_2;
import java.util.*;
public class TestRectangle {
 private int length ;
 private int breadth;
 
	public int getLength() {
	return length;
}

public void setLength(int length) {
	this.length = length;
}

public int getBreadth() {
	return breadth;
}

public void setBreadth(int breadth) {
	this.breadth = breadth;
}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		TestRectangle rect1 = new TestRectangle();
		TestRectangle rect2 = new TestRectangle();
		TestRectangle rect3 = new TestRectangle();
		TestRectangle rect4 = new TestRectangle();
		TestRectangle rect5 = new TestRectangle();
		
		System.out.println("Enter Length");
		int l1 = sc.nextInt();
		rect1.setLength(l1);
		System.out.println("Enter Breadth");
		int b1 = sc.nextInt();
		rect1.setBreadth(b1);
		int area1 = rect1.getLength() * rect1.getBreadth();
		System.out.println("Area : " + area1);
        System.out.println("*********************");
        
        System.out.println("Enter Length");
		int l2 = sc.nextInt();
		rect2.setLength(l2);
		System.out.println("Enter Breadth");
		int b2 = sc.nextInt();
		rect2.setBreadth(b2);
		int area2 = rect2.getLength() * rect2.getBreadth();
		System.out.println("Area : " + area2);
        System.out.println("*********************");
        
        System.out.println("Enter Length");
		int l3 = sc.nextInt();
		rect3.setLength(l3);
		System.out.println("Enter Breadth");
		int b3 = sc.nextInt();
		rect3.setBreadth(b3);
		int area3 = rect3.getLength() * rect3.getBreadth();
		System.out.println("Area : " + area3);
        System.out.println("*********************");
        
        System.out.println("Enter Length");
		int l4 = sc.nextInt();
		rect4.setLength(l4);
		System.out.println("Enter Breadth");
		int b4 = sc.nextInt();
		rect4.setBreadth(b4);
		int area4 = rect4.getLength() * rect4.getBreadth();
		System.out.println("Area : " + area4);
        System.out.println("*********************");
        
        System.out.println("Enter Length");
		int l5 = sc.nextInt();
		rect5.setLength(l5);
		System.out.println("Enter Breadth");
		int b5 = sc.nextInt();
		rect5.setBreadth(b5);
		int area5 = rect5.getLength() * rect5.getBreadth();
		System.out.println("Area : " + area5);
        System.out.println("*********************");
	}

}
