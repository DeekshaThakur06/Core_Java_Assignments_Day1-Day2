package ProblemStatement3_2;

public class TestMedicine {

	public static void main(String[] args) {
		int arr[] = new int[10];
		Tablet tab = new Tablet();
		Syrup syrup = new Syrup();
		Ointment oin = new Ointment();
		Location locate = new Location();
		
		int num = (int) ((Math.random()) * 10);
		switch(num) {
		
		case 1 : 
			System.out.println(locate.displayLabel());
			System.out.println(tab.displayLabel());
			break;
		
		case 2 : 
			System.out.println(locate.displayLabel());
			System.out.println(syrup.displayLabel());
			break;
		
		case 3 : 
			System.out.println(locate.displayLabel());
			System.out.println(oin.displayLabel());
			break;
			
		default :
			System.out.println("Invalid Choice");
		}
	

	}

}

interface MedicineInfo{
	abstract String displayLabel();
}

class Tablet implements MedicineInfo{

	@Override
	public String displayLabel() {
		// TODO Auto-generated method stub
		return "Store in cool dry place";
	}
	
}
class Syrup implements MedicineInfo{

	@Override
	public String displayLabel() {
		// TODO Auto-generated method stub
		return "Keep out of reach of children";
	}
	
}
class Ointment implements MedicineInfo{

	@Override
	public String displayLabel() {
		// TODO Auto-generated method stub
		return "For external use only.";
	}
	
}
class Location implements MedicineInfo{

	@Override
	public String displayLabel() {
		// TODO Auto-generated method stub
		return "Name : Pharmaceutical Company  '\n' Address : Bangalore";
	}
	
}