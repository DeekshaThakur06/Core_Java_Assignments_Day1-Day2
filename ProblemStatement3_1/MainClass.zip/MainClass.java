package ProblemStatement3_1;

public class MainClass {

	public static void main(String[] args) {
		Piano piano = new Piano();
		Flute flute = new Flute();
		Guitar guitar = new Guitar();
		System.out.println(piano.play());
		System.out.println(flute.play());
		System.out.println(guitar.play());
		System.out.println("-------------------------------");
		String  arr[] = new String[10];
		
		arr[0] = piano.play();
		arr[1] = flute.play();
		arr[2] = guitar.play();
		boolean val = piano instanceof Piano;
		System.out.println("Instance of piano is store at : 0");
		System.out.println("Instance of flute is store at : 1");
		System.out.println("Instance of guitar is store at : 2");
		
		
		
	}

}

abstract class Instrument {

	abstract String play();
}
	class Piano extends Instrument{

		@Override
		String play() {
			// TODO Auto-generated method stub
			return ("Piano is playing tan tan tan tan");
		}
		
	}
	class Flute extends Instrument{
		@Override
		String play() {
			return ("Flute is playing toot toot toot toot");
		}
	}
	class Guitar extends Instrument{

		@Override
		String play() {
			return ("Guitar is playing tin tin tin");
			
		}}
		


